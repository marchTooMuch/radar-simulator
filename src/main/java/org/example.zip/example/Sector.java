package org.example;

import javafx.beans.binding.Bindings;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;

public class Sector {
    private static final double SECTOR_ANGLE = 90;

    public static Arc create(Scene scene) {
        Arc sector = new Arc();
        sector = new Arc();
        sector.setStyle("-fx-background-color: transparent;");

        sector.setType(ArcType.ROUND);
        sector.setStartAngle(90 - SECTOR_ANGLE / 2);
        sector.setLength(SECTOR_ANGLE);
        sector.setFill(Color.WHITE.deriveColor(1, 1, 1, 0.1)); // слегка прозрачный белый
        sector.setStroke(Color.WHITE);
        sector.setStrokeWidth(2);

        sector.centerXProperty().bind(scene.widthProperty().divide(2));
        sector.centerYProperty().bind(scene.heightProperty().subtract(50));

        // Радиусы
        sector.radiusXProperty().bind(scene.widthProperty().multiply(0.48));
        sector.radiusYProperty().bind(scene.heightProperty().multiply(0.9));
        return sector;
    }

}
